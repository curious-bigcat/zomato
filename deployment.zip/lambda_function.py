import json
import boto3
import pymongo

# Connect to MongoDB Atlas cluster
client = pymongo.MongoClient("mongodb+srv://bharaths:Blippi123@restaurant.psa7j2k.mongodb.net/?retryWrites=true&w=majority&appName=restaurant")

sagemaker_runtime_client = boto3.client("sagemaker-runtime")

def lambda_handler(event, context):
    try:
        # Extract the query parameter 'query' from the event
        query_param = event.get('queryStringParameters', {}).get('query', '')

        if query_param:
            embedding = get_embedding(query_param)
            # Run the vector search pipeline
            results = run_vector_search(embedding)
            return {
                'statusCode': 200,
                'body': json.dumps({'results': results})
            }
        else:
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'No query parameter provided'})
            }

    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }

def get_embedding(synopsis):
    input_data = {"text_inputs": synopsis}
    response = sagemaker_runtime_client.invoke_endpoint(
        EndpointName="jumpstart-dft-hf-textembedding-all-minilm-l6-snow",
        Body=json.dumps(input_data),
        ContentType="application/json"
    )
    result = json.loads(response["Body"].read().decode())
    embedding = result["embedding"][0]
    return embedding

def run_vector_search(query_vector):
    # Define the pipeline for vector search
    pipeline = [
        {
            '$vectorSearch': {
                'index': 'vector', 
                'path': 'embedding', 
                'queryVector': query_vector, 
                'numCandidates': 200, 
                'limit': 10
            }
        },
        {
            '$project': {
                '_id': 0,
                'name': 1, 
                'city': 1, 
                'address': 1, 
                'cuisines': 1,
                'timings': 1, 
                'score': {
                    '$meta': 'vectorSearchScore'
                }
            }
        }
    ]

    # Run the pipeline
    result = client["zomato"]["restaurants"].aggregate(pipeline)

    # Format the results
    formatted_results = []
    for doc in result:
        formatted_results.append(doc)

    return formatted_results
